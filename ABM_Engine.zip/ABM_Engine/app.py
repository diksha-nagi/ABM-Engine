"""
ABM Engine — Flask API Server
Run: python app.py
Then open: http://localhost:5000
"""

from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
import threading
import sys
import os

# ── Make sure we can import the ABM engine script ──────────────────
SCRIPTS_DIR = os.path.join(os.path.dirname(__file__), "Scripts")
sys.path.insert(0, SCRIPTS_DIR)

# Import the core functions from your existing script
from step3_extract_signals import (
    scrape_company,
    fetch_job_signals,
    extract_signals,
    score_company,
    generate_email,
)

app = Flask(__name__, static_folder=".")
CORS(app)

# ── Serve the HTML page ────────────────────────────────────────────
@app.route("/")
def index():
    return send_from_directory(".", "abm_dashboard.html")


# ── Single company endpoint ────────────────────────────────────────
@app.route("/api/run", methods=["POST"])
def run_company():
    data = request.json or {}
    company  = (data.get("company")  or "").strip()
    website  = (data.get("website")  or "").strip()
    linkedin = (data.get("linkedin") or "").strip()

    if not company or not website:
        return jsonify({"error": "company and website are required"}), 400

    try:
        # Step 1: Scrape
        raw_text = scrape_company(website, linkedin)

        # Step 2: Job signals
        job_text = fetch_job_signals(company)
        if job_text:
            raw_text += f"\n\n[JOB LISTINGS]\n{job_text}"

        # Step 3: Extract signals
        signals = extract_signals(raw_text)

        # Step 4: Score
        score, angle = score_company(signals)

        # Step 5: Generate email
        email = generate_email(company, signals, score, angle)

        return jsonify({
            "company":  company,
            "website":  website,
            "linkedin": linkedin,
            "signals":  signals,
            "score":    score,
            "angle":    angle,
            "email":    email,
        })

    except Exception as e:
        return jsonify({"error": str(e)}), 500


# ── Batch endpoint — runs companies sequentially, streams updates ──
@app.route("/api/batch", methods=["POST"])
def run_batch():
    data = request.json or {}
    companies = data.get("companies", [])

    if not companies:
        return jsonify({"error": "No companies provided"}), 400

    results = []
    for item in companies:
        company  = (item.get("company")  or "").strip()
        website  = (item.get("website")  or "").strip()
        linkedin = (item.get("linkedin") or "").strip()

        if not company or not website:
            results.append({"company": company, "error": "Missing company or website"})
            continue

        try:
            raw_text = scrape_company(website, linkedin)
            job_text = fetch_job_signals(company)
            if job_text:
                raw_text += f"\n\n[JOB LISTINGS]\n{job_text}"
            signals = extract_signals(raw_text)
            score, angle = score_company(signals)
            email = generate_email(company, signals, score, angle)
            results.append({
                "company":  company,
                "website":  website,
                "linkedin": linkedin,
                "signals":  signals,
                "score":    score,
                "angle":    angle,
                "email":    email,
            })
        except Exception as e:
            results.append({"company": company, "error": str(e)})

    return jsonify({"results": results})


if __name__ == "__main__":
    print("\n" + "═"*50)
    print("  ABM Engine Server starting...")
    print("  Open: http://localhost:5000")
    print("═"*50 + "\n")
    app.run(debug=False, port=5000, threaded=True)