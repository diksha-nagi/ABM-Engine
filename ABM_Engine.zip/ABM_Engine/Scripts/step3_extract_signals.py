"""
╔══════════════════════════════════════════════════════════════════╗
║           ABM ENGINE — COMPLETE REWRITE (COPY & PASTE)          ║
║                                                                  ║
║  HOW TO RUN:                                                     ║
║    Single company:                                               ║
║      python abm_engine_complete.py --company "HashiCorp"         ║
║        --website https://www.hashicorp.com                       ║
║        --linkedin https://linkedin.com/company/hashicorp         ║
║                                                                  ║
║    Batch from CSV:                                               ║
║      python abm_engine_complete.py --batch companies.csv         ║
║                                                                  ║
║  REQUIREMENTS:                                                   ║
║    pip install requests beautifulsoup4 openai                    ║
║                                                                  ║
║  OPENAI KEY:                                                     ║
║    Set the OPENAI_API_KEY variable below (line ~60)              ║
╚══════════════════════════════════════════════════════════════════╝
"""

import re
import os
import csv
import sys
import json
import argparse
import time
from datetime import datetime

import requests
from bs4 import BeautifulSoup

# ─────────────────────────────────────────────────────────────────────
# CONFIG  — edit these two values before running
# ─────────────────────────────────────────────────────────────────────

OPENAI_API_KEY = "YOUR_OPENAI_API_KEY_HERE"   # ← paste your key here
OUTPUT_FOLDER  = "abm_outputs"                 # folder where results are saved

# ─────────────────────────────────────────────────────────────────────
# STEP 1 — SCRAPER
# Scrapes homepage + 6 sub-pages per company so signals are actually
# present in the text (careers, security, about, tech, integrations)
# ─────────────────────────────────────────────────────────────────────

HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/120.0.0.0 Safari/537.36"
    ),
    "Accept-Language": "en-US,en;q=0.9",
}

# Sub-pages to scrape in addition to the homepage
# These are where cloud/hiring/tech signals actually live
EXTRA_PATHS = [
    "/careers",
    "/jobs",
    "/about",
    "/security",
    "/technology",
    "/integrations",
    "/tech-stack",
    "/platform",
    "/developers",
    "/engineering",
]


def scrape_page(url):
    """
    Scrape a single URL. Returns combined visible text + infrastructure
    URLs (script/link src attributes) which reveal CDN and cloud provider.
    Returns empty string on failure — never raises.
    """
    try:
        resp = requests.get(url, headers=HEADERS, timeout=12, allow_redirects=True)

        if resp.status_code != 200:
            return ""

        soup = BeautifulSoup(resp.text, "html.parser")

        # Collect all script src, link href, and meta content
        # These URLs reveal cloud provider (e.g. cloudfront.net = AWS)
        infra_urls = []
        for tag in soup.find_all("script", src=True):
            infra_urls.append(tag["src"])
        for tag in soup.find_all("link", href=True):
            infra_urls.append(tag["href"])
        for tag in soup.find_all("meta"):
            if tag.get("content"):
                infra_urls.append(tag["content"])

        infra_text = " ".join(infra_urls)

        # Detect common bot protection pages — skip them
        raw_text = soup.get_text(separator=" ", strip=True).lower()
        if any(x in raw_text for x in [
            "verifying your browser",
            "security check",
            "enable javascript",
            "ddos protection",
            "checking your browser",
        ]):
            return ""

        # Remove non-content tags for cleaner visible text
        for tag in soup(["script", "style", "noscript", "svg", "head"]):
            tag.decompose()

        visible_text = soup.get_text(separator=" ", strip=True)

        return visible_text + "  " + infra_text

    except Exception:
        return ""


def scrape_company(website_url, linkedin_url=""):
    """
    Scrape homepage + all extra sub-pages for a company.
    Also scrapes LinkedIn if provided (best-effort, often blocked).
    Returns a single merged text string ready for signal extraction.
    """
    print(f"  Scraping homepage: {website_url}")
    homepage_text = scrape_page(website_url)

    # Try sub-pages — silently skip ones that 404 or redirect away
    base = website_url.rstrip("/")
    sub_texts = []

    for path in EXTRA_PATHS:
        url = base + path
        text = scrape_page(url)

        # Only keep if we got meaningful content
        # Use length check rather than content comparison to handle short homepages
        if len(text) > 300 and len(text) > len(homepage_text) * 0.3:
            sub_texts.append(f"\n\n[PAGE: {path}]\n{text}")
            print(f"  ✅ Got content from {path}")
        else:
            print(f"  — Skipped {path} (empty or redirect)")

    # LinkedIn (best-effort — often returns 404 or login wall)
    linkedin_text = ""
    if linkedin_url:
        print(f"  Scraping LinkedIn: {linkedin_url}")
        linkedin_text = scrape_page(linkedin_url)
        if len(linkedin_text) < 200:
            print("  ⚠️  LinkedIn blocked or empty")
            linkedin_text = ""
        else:
            print("  ✅ Got LinkedIn content")

    # Merge all text together
    all_text = homepage_text
    all_text += "".join(sub_texts)
    if linkedin_text:
        all_text += f"\n\n[LINKEDIN]\n{linkedin_text}"

    return all_text


# ─────────────────────────────────────────────────────────────────────
# STEP 2 — JOB SIGNAL FETCHER
# Uses Remotive public API (no key needed) to get real job descriptions.
# Job descriptions are the #1 source of cloud + hiring signals.
# ─────────────────────────────────────────────────────────────────────

def fetch_job_signals(company_name):
    """
    Query Remotive public jobs API for the company.
    Returns job description text if found, empty string otherwise.
    This is the best source of DevOps/SRE/cloud stack signals.
    """
    try:
        resp = requests.get(
            "https://remotive.com/api/remote-jobs",
            headers=HEADERS,
            timeout=10,
        )
        data = resp.json()
        jobs = data.get("jobs", [])

        matched = []
        for job in jobs:
            if company_name.lower() in job.get("company_name", "").lower():
                title = job.get("title", "")
                desc  = BeautifulSoup(
                    job.get("description", ""), "html.parser"
                ).get_text(separator=" ", strip=True)
                matched.append(f"Job Title: {title}\nDescription: {desc[:1500]}")

        if matched:
            print(f"  ✅ Found {len(matched)} job listings via Remotive API")
            return "\n\n".join(matched)

    except Exception:
        pass

    print("  — No jobs found via Remotive API")
    return ""


# ─────────────────────────────────────────────────────────────────────
# STEP 3 — SIGNAL EXTRACTOR
# Fixed version with:
#   - Word-boundary regex matching (no false positives)
#   - googleapis.com / gstatic.com excluded from GCP detection
#   - 90+ keywords across all signals (was ~30)
#   - Multi-cloud auto-detection
#   - Compliance domain stacking (multiple domains allowed)
#   - Old signal header stripping (prevents self-pollution)
# ─────────────────────────────────────────────────────────────────────

def _match(text, patterns):
    """
    Word-boundary safe match. Case insensitive.
    Prevents 'azure' matching 'azazure' or 'gcp' matching 'recap'.
    """
    for p in patterns:
        escaped = re.escape(p)
        if re.search(
            r"(?<![a-zA-Z0-9])" + escaped + r"(?![a-zA-Z0-9])",
            text,
            re.IGNORECASE,
        ):
            return True
    return False


def _strip_old_signals(text):
    """
    Remove any previously written === EXTRACTED SIGNALS === block.
    Prevents old cached signal values from polluting re-extraction.
    """
    return re.sub(
        r"=== EXTRACTED SIGNALS ===.*?(?===|\Z)",
        "",
        text,
        flags=re.DOTALL | re.IGNORECASE,
    )


def extract_signals(text):
    # Always return a full signals dict — never an empty dict
    default = {
        "cloud_provider":    "Unknown",
        "kubernetes":        "No",
        "devops_hiring":     "No",
        "sre_hiring":        "No",
        "multi_cloud":       "No",
        "security_focus":    "No",
        "microservices":     "No",
        "ai_ml":             "No",
        "data_platform":     "No",
        "finops":            "No",
        "observability":     "No",
        "compliance_domain": "Low-Regulated",
    }
    if not text or len(text.strip()) < 50:
        return default

    text = _strip_old_signals(text)

    signals = {
        "cloud_provider":    "Unknown",
        "kubernetes":        "No",
        "devops_hiring":     "No",
        "sre_hiring":        "No",
        "multi_cloud":       "No",
        "security_focus":    "No",
        "microservices":     "No",
        "ai_ml":             "No",
        "data_platform":     "No",
        "finops":            "No",
        "observability":     "No",
        "compliance_domain": "Low-Regulated",
    }

    # ── CLOUD PROVIDER ───────────────────────────────────────────────
    # Collect all providers found, then decide single or multi-cloud.
    # NOTE: googleapis.com and gstatic.com are Google CDN / Fonts — NOT GCP.
    #       fonts.googleapis.com appears on almost every website and is NOT
    #       evidence of running on Google Cloud Platform.

    providers = set()

    if _match(text, [
        "amazon web services",
        "amazonaws.com",          # S3, EC2, Lambda URLs
        "cloudfront.net",         # AWS CloudFront CDN — strong signal
        "elb.amazonaws",          # AWS Elastic Load Balancer
        "s3.amazonaws",
        "aws.amazon.com",
        "elastic beanstalk",
        "cloudwatch",
        "aws lambda",
        "aws fargate",
        "aws ecs",
        "eks",                    # Elastic Kubernetes Service
        "aws",                    # word-boundary regex in _match handles isolation
    ]):
        providers.add("AWS")

    if _match(text, [
        "microsoft azure",
        "azure.microsoft.com",
        "azureedge.net",          # Azure CDN
        "azure devops",
        "azure functions",
        "azure blob",
        "azure active directory",
        "azure ad",
        "azure kubernetes",
        "azure kubernetes service", # require full phrase for AKS
        "azure-based",
        "built on azure",
        "azure infrastructure",
        "azure cloud",
        "windows azure",
        " azure ",
        "azure",                  # word-boundary regex handles isolation
    ]):
        providers.add("Azure")

    # GCP DETECTION — only very specific infrastructure signals
    # EXCLUDED:
    #   "google cloud"         — appears on /integrations pages ("integrate with Google Cloud")
    #   "google cloud platform"— same issue: integration descriptions
    #   "google app engine"    — vendors list it as a supported deployment target
    #   "gke"                  — alone it's too short, use full phrase
    # KEPT:
    #   "cloud.google.com"     — only appears in actual GCP API/console URLs
    #   "google kubernetes engine" — specific product name
    #   " gcp " / "gcp"        — specific abbreviation rarely used in passing
    #   "google cloud run"     — specific GCP serverless product
    if _match(text, [
        "cloud.google.com",            # actual GCP API/console URL — very specific
        "google cloud run",            # specific GCP serverless product
        "google kubernetes engine",    # specific GCP product name
        "gke cluster",                 # GKE with context = specific
        "google cloud sql",            # specific GCP managed DB
        "google cloud storage",        # specific GCP storage (not just "storage")
        "google cloud functions",      # specific GCP serverless
        "google cloud build",          # specific GCP CI/CD
        "gcp project",                 # GCP-specific terminology
        "gcp account",
        "gcp",                         # word-boundary regex in _match handles isolation
    ]):
        providers.add("GCP")

    # BigQuery only as GCP signal if it's about running ON BigQuery infra,
    # not integrating WITH BigQuery (e.g. "BigQuery Connector for Jira" ≠ GCP)
    if _match(text, ["bigquery"]) and not _match(text, [
        "bigquery connector",
        "connector for bigquery",
        "export to bigquery",
        "integrate with bigquery",
        "bigquery integration",
        "sync to bigquery",
        "send data to bigquery",
    ]):
        providers.add("GCP")

    if len(providers) == 1:
        signals["cloud_provider"] = providers.pop()
    elif len(providers) > 1:
        signals["cloud_provider"] = " + ".join(sorted(providers))
        signals["multi_cloud"] = "Yes"

    # Fallback: if we see generic "cloud" language but no provider, mark it
    if signals["cloud_provider"] == "Unknown" and _match(text, [
        "cloud-based",
        "cloud-native",
        "cloud infrastructure",
        "hosted in the cloud",
        "cloud platform",
        "saas platform",
    ]):
        signals["cloud_provider"] = "Cloud-Based (Unspecified)"

    # ── KUBERNETES ───────────────────────────────────────────────────
    if _match(text, [
        "kubernetes",
        "k8s",
        "eks",
        "aks",
        "gke",
        "helm chart",
        "helm charts",
        "kubectl",
        "container orchestration",
        "pod deployment",
        "openshift",
        "rancher",
    ]):
        signals["kubernetes"] = "Yes"

    # ── DEVOPS HIRING ────────────────────────────────────────────────
    if _match(text, [
        "devops engineer",
        "devops architect",
        "devops role",
        "hiring devops",
        "platform engineer",
        "infrastructure engineer",
        "cloud infrastructure engineer",
        "cloud engineer",
        "cloud platform engineer",
        "build engineer",
        "release engineer",
        "devsecops engineer",
    ]):
        signals["devops_hiring"] = "Yes"

    # ── SRE HIRING ───────────────────────────────────────────────────
    if _match(text, [
        "site reliability engineer",
        "site reliability engineering",
        "sre engineer",
        "sre role",
        "sre team",
        "sre manager",
        " sre ",
    ]):
        signals["sre_hiring"] = "Yes"

    # ── MICROSERVICES ────────────────────────────────────────────────
    if _match(text, [
        "microservice",
        "microservices",
        "service mesh",
        "istio",
        "envoy proxy",
        "event-driven architecture",
        "event driven architecture",
    ]):
        signals["microservices"] = "Yes"

    # ── AI / ML ──────────────────────────────────────────────────────
    if _match(text, [
        "machine learning",
        "artificial intelligence",
        "deep learning",
        "large language model",
        "llm",
        "generative ai",
        "gen ai",
        "genai",
        "openai",
        "ai platform",
        "ai-powered",
        "ai powered",
        "hiro ai",
        "hiroai",
        "-ai ",                   # product names like HiroAI, SamyxAI
        "ai-",                    # AI-Powered, AI-native, AI-driven
        "ai-native",
        "ai native",
        "ml pipeline",
        "mlops",
        "ml ops",
        "neural network",
        "natural language processing",
        "nlp",
        "predictive model",
        "autonomous",
        "ai agents",
        "agentic",
        " ai ",
        " ml ",
    ]):
        signals["ai_ml"] = "Yes"

    # ── DATA PLATFORM ────────────────────────────────────────────────
    if _match(text, [
        "data platform",
        "analytics platform",
        "data lake",
        "data warehouse",
        "data lakehouse",
        "data mesh",
        "data fabric",
        "snowflake",
        "databricks",
        "apache spark",
        " spark ",
        " dbt ",
        "apache airflow",
        " airflow ",
        "fivetran",
        "stitch data",
        "redshift",
        "azure synapse",
        "google bigquery",
    ]):
        signals["data_platform"] = "Yes"

    # ── FINOPS ───────────────────────────────────────────────────────
    if _match(text, [
        "finops",
        "cloud cost",
        "cost optimization",
        "cloud spend",
        "cost governance",
        "cloud roi",
        "reduce infrastructure cost",
        "cloud budget",
        "cloud efficiency",
        "reserved instances",
        "savings plan",
        "rightsizing",
        "cloud billing",
        "cost allocation",
        "cost per customer",
        "unit economics",
        "infrastructure spend",
        "optimize cloud",
        "cloud financial",
    ]):
        signals["finops"] = "Yes"

    # ── OBSERVABILITY ────────────────────────────────────────────────
    if _match(text, [
        "observability",
        "opentelemetry",
        "distributed tracing",
        "log management",
        "log aggregation",
        "monitoring",
        "metrics",
        "alerting",
        "incident response",
        "prometheus",
        "grafana",
        "datadog",
        "splunk",
        "dynatrace",
        "new relic",
        "elastic apm",
        "jaeger",
        "zipkin",
        "pagerduty",
        "opsgenie",
        "real-time visibility",
        "performance monitoring",
        " apm ",
    ]):
        signals["observability"] = "Yes"

    # ── SECURITY ─────────────────────────────────────────────────────
    if _match(text, [
        "security",
        "cybersecurity",
        "zero trust",
        "siem",
        "soc 2",
        "soc2",
        "iso 27001",
        "gdpr",
        "penetration test",
        "vulnerability",
        "identity access management",
        "secrets management",
        "vault",
        "devsecops",
        "enterprise-grade",
        "enterprise grade",
        "audit-ready",
        "audit ready",
        "independently audited",
        "compliance certified",
        "privacy by design",
        "ccpa",
        "fedramp",
    ]):
        signals["security_focus"] = "Yes"

    # ── COMPLIANCE DOMAIN (can detect multiple, stacks them) ─────────
    domains = []

    if _match(text, [
        "payroll",
        "tax filing",
        "tax compliance",
        "tax software",
        "w-2",
        " 1099 ",
        "multi-jurisdictional tax",
        "payroll processing",
        "garnishment",
        "payroll tax",
    ]):
        domains.append("Payroll / Tax")

    if _match(text, [
        "hipaa",
        " ehr ",
        " emr ",
        "clinical data",
        "patient data",
        " phi ",
        "medical record",
        "electronic health record",
        "health information exchange",
        "healthcare compliance",
        "hipaa compliant",
        "healthcare provider",
        "hospital system",
    ]):
        # NOTE: bare "healthcare" removed — SaaS companies list it as a CLIENT VERTICAL
        # e.g. "we serve healthcare teams" ≠ the company itself is a healthcare company.
        # Only fire when there is a regulatory/clinical keyword present.
        domains.append("Healthcare")

    # FINANCIAL DOMAIN — two-tier approach to avoid false positives
    # Problem: SaaS vendors describe their CLIENTS as financial companies,
    # which makes them appear to be financial companies themselves.
    # e.g. HashiCorp lists Deutsche Bank as a customer → "financial services" matches
    # e.g. Greenshades integrates with AP systems → "accounts payable" matches
    # e.g. Tempo mentions "AR automation" in case studies → "accounts receivable" matches
    #
    # Solution:
    #   DEFINITIVE keywords (1 is enough) — rarely mentioned unless you ARE that industry
    #   SOFT keywords (need 2 or more to fire) — often used in client descriptions
    
    financial_definitive = [
        "banking",                # you don't say "banking" unless you are/serve banks
        "pci dss",
        "pci-dss",
        "trading platform",
        "capital markets",
        "insurtech",
        "insurance company",
        "insurance provider",
        " nbfc ",
        "financial aggregator",
        "credit data",
        "trade credit",
        "invoice financing",
        "gstin",
        "gst compliance",
        "order to cash",
        "procure to pay",
        "month-end close",
        "financial close",
        "revenue recognition",
        " sox ",
        "cloud financial management",  # UniCloud type: financial cloud ops
        # AP/AR/reconciliation are definitive when they're the PRODUCT, not just a keyword:
        "accounts receivable automation",  # "AR automation" = that IS their product
        "accounts payable automation",     # "AP automation" = that IS their product
        "accounts payable software",
        "accounts receivable software",
        "automated reconciliation",        # reconciliation as a product feature
        "reconciliation software",
        "reconciliation platform",
        "financial reconciliation",
        "account reconciliation",
        "bank reconciliation",
    ]
    
    financial_soft = [
        "financial services",  # vendors list finance firms as customers — needs 2+ to fire
        # REMOVED: "accounts payable" — appears as LinkedIn "AP Specialist jobs" sidebar noise
        # REMOVED: "accounts receivable" — same LinkedIn sidebar noise issue
        # REMOVED: "reconciliation" — HR/payroll tools often "reconcile" payroll with ERP
        " cfo ",               # mentions CFO in their content
        "asset management",    # legitimate financial indicator if paired with another
        "fintech company",     # "fintech company" = them; vs "fintech clients" = not them
    ]
    
    financial_definitive_match = _match(text, financial_definitive)
    financial_soft_count = sum(1 for p in financial_soft if _match(text, [p]))
    
    if financial_definitive_match or financial_soft_count >= 2:
        domains.append("Financial")

    # GOVERNMENT DOMAIN — require hard regulatory signals ONLY
    # "public sector", "state agency", "government agency" are client-vertical descriptions
    # e.g. "we serve public sector teams" does NOT mean you are a government vendor
    # Only fire when the company itself is government-regulated or FedRAMP certified
    if _match(text, [
        "fedramp",
        "fedramp authorized",
        "fedramp moderate",
        "fedramp high",
        "govcloud",
        "aws govcloud",
        "azure government",
        "dod contract",
        "itar compliant",
        "itar certified",
        "cmmc certified",
        "fisma compliant",
        "government contractor",
        "defense contractor",
        "cleared facility",
    ]):
        domains.append("Government")

    # E-COMMERCE DOMAIN — require the CATEGORY WORD + platform signal
    #
    # ROOT CAUSE: /integrations pages list Shopify, WooCommerce, Magento, BigCommerce
    # as INTEGRATION TARGETS — any SaaS tool that connects to e-commerce stores
    # shows all these platform names together, triggering the 2-signal rule.
    #
    # SOLUTION: Require "ecommerce"/"e-commerce" (the self-describing category word)
    # to be present. Companies that ARE e-commerce platforms say "ecommerce" about
    # themselves. Companies that just INTEGRATE with stores say "Shopify integration".
    #
    # Exception: if 4+ platform signals co-occur, that's also strong enough.
    ecomm_category = _match(text, ["e-commerce", "ecommerce", "retail platform", "online store", "storefront"])
    ecomm_platform_signals = [
        "shopify", "woocommerce", "magento", "bigcommerce",
        "shopping cart", "product catalog", "cart abandonment",
        "order fulfillment", "omnichannel retail", "omni-channel retail",
    ]
    ecomm_platform_count = sum(1 for p in ecomm_platform_signals if _match(text, [p]))
    
    # Fire E-Commerce if:
    # - Category word + at least 1 platform signal (e.g. PyRops: "E-commerce" in their industries + WooCommerce)
    # - OR 5+ platform signals (unlikely for a non-e-commerce company; raised from 4 because
    #   /integrations pages list Shopify+WooCommerce+Magento+BigCommerce = 4 for any SaaS)
    if (ecomm_category and ecomm_platform_count >= 1) or ecomm_platform_count >= 5:
        domains.append("E-Commerce / Retail")

    signals["compliance_domain"] = " | ".join(domains) if domains else "Low-Regulated"

    return signals


# ─────────────────────────────────────────────────────────────────────
# STEP 4 — SCORING ENGINE
# Converts signals into a priority score (0–100) and a value angle.
# ─────────────────────────────────────────────────────────────────────

COMPLIANCE_WEIGHTS = {
    "Payroll / Tax":       20,
    "Healthcare":          20,
    "Financial":           20,
    "Government":          15,
    "E-Commerce / Retail": 10,
    "Low-Regulated":        0,
}

CLOUD_WEIGHTS = {
    "AWS":                      20,
    "Azure":                    20,
    "GCP":                      20,
    "AWS + Azure + GCP":        25,
    "AWS + Azure":              22,
    "AWS + GCP":                22,
    "Azure + GCP":              22,
    "Cloud-Based (Unspecified)": 8,
    "Unknown":                   0,
}


def score_company(signals):
    score = 0

    # Cloud provider — base signal
    cloud = signals.get("cloud_provider", "Unknown")
    score += CLOUD_WEIGHTS.get(cloud, 0)

    # Kubernetes — high-value signal (complex infra)
    if signals.get("kubernetes") == "Yes":
        score += 20

    # Hiring signals
    if signals.get("devops_hiring") == "Yes":
        score += 15
    if signals.get("sre_hiring") == "Yes":
        score += 10

    # Multi-cloud — extra complexity = extra opportunity
    if signals.get("multi_cloud") == "Yes":
        score += 10

    # Tech stack signals
    if signals.get("microservices") == "Yes":
        score += 8
    if signals.get("ai_ml") == "Yes":
        score += 8
    if signals.get("data_platform") == "Yes":
        score += 8
    if signals.get("finops") == "Yes":
        score += 10
    if signals.get("observability") == "Yes":
        score += 8
    if signals.get("security_focus") == "Yes":
        score += 8

    # Compliance domain (use highest weight if multiple)
    compliance_str = signals.get("compliance_domain", "Low-Regulated")
    compliance_score = 0
    for domain in compliance_str.split(" | "):
        domain_weight = COMPLIANCE_WEIGHTS.get(domain.strip(), 0)
        compliance_score = max(compliance_score, domain_weight)
    score += compliance_score

    # Cap at 100
    score = min(score, 100)

    # ── VALUE ANGLE — pick the most relevant pitch ──────────────────
    if signals.get("kubernetes") == "Yes" and signals.get("multi_cloud") == "Yes":
        angle = "Multi-Cloud Kubernetes Reliability"
    elif signals.get("kubernetes") == "Yes":
        angle = "Kubernetes Optimization & Reliability"
    elif signals.get("sre_hiring") == "Yes" and signals.get("devops_hiring") == "Yes":
        angle = "DevOps & SRE Automation at Scale"
    elif signals.get("devops_hiring") == "Yes" or signals.get("sre_hiring") == "Yes":
        angle = "Cloud Reliability & DevOps Acceleration"
    elif signals.get("finops") == "Yes":
        angle = "Cloud Cost Optimization & FinOps"
    elif signals.get("security_focus") == "Yes" and compliance_score >= 15:
        angle = "Compliance-Ready Cloud Security"
    elif signals.get("security_focus") == "Yes":
        angle = "Cloud Security & Governance"
    elif signals.get("ai_ml") == "Yes" and signals.get("data_platform") == "Yes":
        angle = "AI/ML Data Platform Infrastructure"
    elif signals.get("ai_ml") == "Yes":
        angle = "AI Infrastructure Scaling"
    elif signals.get("data_platform") == "Yes":
        angle = "Data Platform Modernization"
    elif signals.get("multi_cloud") == "Yes":
        angle = "Multi-Cloud Strategy & Management"
    elif signals.get("observability") == "Yes":
        angle = "Observability & Platform Reliability"
    elif compliance_score >= 15:
        angle = "Compliance-Driven Cloud Infrastructure"
    elif cloud not in ("Unknown", ""):
        angle = "Cloud Infrastructure Optimization"
    else:
        angle = "Platform Modernization"

    return score, angle


# ─────────────────────────────────────────────────────────────────────
# STEP 5 — AI EMAIL GENERATOR
# Uses OpenAI GPT to write personalized outreach emails.
# Falls back to a template email if no API key is set.
# ─────────────────────────────────────────────────────────────────────

def build_prompt(company_name, signals, score, angle):
    """Build the GPT prompt for outreach email generation."""
    signal_lines = "\n".join(
        f"  {k.replace('_', ' ').title()}: {v}"
        for k, v in signals.items()
    )

    return f"""You are an expert B2B SaaS sales development representative (SDR).

Write a short, personalized cold outreach email for the following company.

COMPANY: {company_name}
PRIORITY SCORE: {score}/100
VALUE ANGLE: {angle}

DETECTED SIGNALS:
{signal_lines}

EMAIL RULES:
- Maximum 120 words in the body
- Address the Head of Engineering or VP Engineering
- Lead with a specific insight about their tech environment (use the detected signals)
- One clear pain point relevant to their value angle
- One sentence about how we solve it
- End with a single low-friction CTA: "Would a 15-minute call this week make sense?"
- Do NOT use buzzwords like "synergy", "leverage", "deep dive", "game-changing"
- Do NOT make up facts or metrics not provided
- Tone: direct, confident, peer-to-peer, not salesy

OUTPUT FORMAT (exactly this structure):
Subject: [subject line here]

Body:
[email body here]
"""


def generate_email_openai(prompt):
    """Call OpenAI API to generate the email."""
    if not OPENAI_API_KEY or OPENAI_API_KEY == "YOUR_OPENAI_API_KEY_HERE":
        return None  # Will fall back to template

    headers = {
        "Authorization": f"Bearer {OPENAI_API_KEY}",
        "Content-Type": "application/json",
    }
    payload = {
        "model": "gpt-3.5-turbo",
        "messages": [
            {"role": "system", "content": "You are an expert B2B sales outreach writer."},
            {"role": "user",   "content": prompt},
        ],
        "temperature": 0.7,
        "max_tokens": 400,
    }

    try:
        resp = requests.post(
            "https://api.openai.com/v1/chat/completions",
            headers=headers,
            json=payload,
            timeout=30,
        )
        data = resp.json()
        return data["choices"][0]["message"]["content"].strip()
    except Exception as e:
        print(f"  ⚠️  OpenAI error: {e}")
        return None


def generate_email_template(company_name, signals, score, angle):
    """
    Fallback template email when no OpenAI key is provided.
    Uses detected signals to personalise naturally.
    """
    cloud = signals.get("cloud_provider", "Unknown")
    has_k8s    = signals.get("kubernetes")    == "Yes"
    has_devops = signals.get("devops_hiring") == "Yes"
    has_sre    = signals.get("sre_hiring")    == "Yes"
    has_finops = signals.get("finops")        == "Yes"
    has_sec    = signals.get("security_focus")== "Yes"
    compliance = signals.get("compliance_domain", "Low-Regulated")

    # Build a tailored opening line based on detected signals
    if has_k8s and cloud not in ("Unknown", ""):
        opener = (
            f"I noticed {company_name} is running Kubernetes on {cloud} — "
            f"that's typically where infrastructure teams start feeling the squeeze "
            f"between reliability targets and deployment velocity."
        )
    elif has_devops or has_sre:
        opener = (
            f"I saw {company_name} is actively hiring for "
            f"{'SRE' if has_sre else 'DevOps'} roles — "
            f"a strong signal that your infrastructure is scaling faster than your tooling."
        )
    elif has_finops:
        opener = (
            f"With cloud costs under more scrutiny than ever, "
            f"I wanted to reach out to {company_name} about how teams like yours "
            f"are cutting cloud spend without slowing down delivery."
        )
    elif has_sec and "Low-Regulated" not in compliance:
        opener = (
            f"Operating in {compliance.split(' | ')[0]} means compliance and cloud security "
            f"aren't optional — I wanted to reach out to {company_name} about "
            f"how we help teams meet those requirements without slowing down engineering."
        )
    elif cloud not in ("Unknown", ""):
        opener = (
            f"I was looking at {company_name}'s infrastructure profile "
            f"and noticed you're running on {cloud}."
        )
    else:
        opener = (
            f"I wanted to reach out to {company_name} — "
            f"based on your engineering footprint, it looks like you're at an inflection point."
        )

    subject = f"Quick question about {company_name}'s {angle.lower()}"

    body = f"""Hi [Name],

{opener}

We work with engineering teams to {angle.lower()} — typically reducing toil, improving reliability, and giving your team back hours they're currently spending on reactive work.

Would a 15-minute call this week make sense?

Best,
[Your Name]
[Your Company]"""

    return f"Subject: {subject}\n\nBody:\n{body}"


def generate_email(company_name, signals, score, angle):
    """Try OpenAI first, fall back to template if no key or error."""
    prompt = build_prompt(company_name, signals, score, angle)
    ai_email = generate_email_openai(prompt)
    if ai_email:
        print("  ✅ Email generated via OpenAI")
        return ai_email
    else:
        print("  — Using template email (set OPENAI_API_KEY for AI-generated emails)")
        return generate_email_template(company_name, signals, score, angle)


# ─────────────────────────────────────────────────────────────────────
# STEP 6 — OUTPUT WRITER
# Saves results per company as a .txt file and appends to a master CSV.
# ─────────────────────────────────────────────────────────────────────

def save_outputs(company_name, website_url, linkedin_url,
                 signals, score, angle, email, raw_text):
    """Save individual company output + append row to master CSV."""

    os.makedirs(OUTPUT_FOLDER, exist_ok=True)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    safe_name = re.sub(r"[^a-zA-Z0-9_\-]", "_", company_name.lower())

    # ── Individual company .txt file ────────────────────────────────
    txt_path = os.path.join(OUTPUT_FOLDER, f"{safe_name}_{timestamp}.txt")

    with open(txt_path, "w", encoding="utf-8") as f:
        f.write("=" * 60 + "\n")
        f.write(f"COMPANY: {company_name}\n")
        f.write(f"Website: {website_url}\n")
        f.write(f"LinkedIn: {linkedin_url}\n")
        f.write(f"Processed: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write("=" * 60 + "\n\n")

        f.write("── EXTRACTED SIGNALS ──\n")
        for k, v in signals.items():
            f.write(f"  {k:<22} {v}\n")
        f.write(f"\n  {'priority_score':<22} {score}/100\n")
        f.write(f"  {'value_angle':<22} {angle}\n")

        f.write("\n\n── GENERATED EMAIL ──\n")
        f.write(email)

    # ── Master CSV (append mode) ────────────────────────────────────
    csv_path = os.path.join(OUTPUT_FOLDER, "abm_master_results.csv")
    file_exists = os.path.isfile(csv_path)

    fieldnames = [
        "company_name", "website", "linkedin",
        "cloud_provider", "kubernetes", "devops_hiring", "sre_hiring",
        "multi_cloud", "security_focus", "microservices", "ai_ml",
        "data_platform", "finops", "observability", "compliance_domain",
        "priority_score", "value_angle", "generated_email", "processed_at",
    ]

    with open(csv_path, "a", newline="", encoding="utf-8") as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        if not file_exists:
            writer.writeheader()
        writer.writerow({
            "company_name":      company_name,
            "website":           website_url,
            "linkedin":          linkedin_url,
            "cloud_provider":    signals.get("cloud_provider"),
            "kubernetes":        signals.get("kubernetes"),
            "devops_hiring":     signals.get("devops_hiring"),
            "sre_hiring":        signals.get("sre_hiring"),
            "multi_cloud":       signals.get("multi_cloud"),
            "security_focus":    signals.get("security_focus"),
            "microservices":     signals.get("microservices"),
            "ai_ml":             signals.get("ai_ml"),
            "data_platform":     signals.get("data_platform"),
            "finops":            signals.get("finops"),
            "observability":     signals.get("observability"),
            "compliance_domain": signals.get("compliance_domain"),
            "priority_score":    score,
            "value_angle":       angle,
            "generated_email":   email.replace("\n", " | "),
            "processed_at":      datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        })

    return txt_path, csv_path


# ─────────────────────────────────────────────────────────────────────
# MAIN PIPELINE
# Runs all steps for a single company and prints a clean summary.
# ─────────────────────────────────────────────────────────────────────

def run_pipeline(company_name, website_url, linkedin_url=""):
    """Run the full ABM pipeline for one company."""

    print(f"\n{'═'*60}")
    print(f"  PROCESSING: {company_name}")
    print(f"{'═'*60}")

    # Step 1: Scrape
    print("\n[1/5] Scraping website...")
    raw_text = scrape_company(website_url, linkedin_url)

    # Step 2: Job signals
    print("\n[2/5] Fetching job signals...")
    job_text = fetch_job_signals(company_name)
    if job_text:
        raw_text += f"\n\n[JOB LISTINGS]\n{job_text}"

    if len(raw_text) < 200:
        print("  ⚠️  Very little text scraped. Signals may be incomplete.")

    # Step 3: Extract signals
    print("\n[3/5] Extracting signals...")
    signals = extract_signals(raw_text)

    # Step 4: Score
    print("\n[4/5] Scoring...")
    score, angle = score_company(signals)

    # Step 5: Generate email
    print("\n[5/5] Generating outreach email...")
    email = generate_email(company_name, signals, score, angle)

    # Save outputs
    txt_path, csv_path = save_outputs(
        company_name, website_url, linkedin_url,
        signals, score, angle, email, raw_text
    )

    # Print summary
    print(f"\n{'─'*60}")
    print(f"  RESULTS FOR: {company_name}")
    print(f"{'─'*60}")
    print(f"  Cloud Provider:   {signals['cloud_provider']}")
    print(f"  Kubernetes:       {signals['kubernetes']}")
    print(f"  DevOps Hiring:    {signals['devops_hiring']}")
    print(f"  SRE Hiring:       {signals['sre_hiring']}")
    print(f"  Multi-Cloud:      {signals['multi_cloud']}")
    print(f"  Security Focus:   {signals['security_focus']}")
    print(f"  Microservices:    {signals['microservices']}")
    print(f"  AI / ML:          {signals['ai_ml']}")
    print(f"  Data Platform:    {signals['data_platform']}")
    print(f"  FinOps:           {signals['finops']}")
    print(f"  Observability:    {signals['observability']}")
    print(f"  Compliance:       {signals['compliance_domain']}")
    print(f"  {'─'*40}")
    print(f"  Priority Score:   {score}/100")
    print(f"  Value Angle:      {angle}")
    print(f"  {'─'*40}")
    print(f"\n  EMAIL PREVIEW:\n")
    print("  " + email.replace("\n", "\n  "))
    print(f"\n  Saved to: {txt_path}")
    print(f"  CSV:      {csv_path}")

    return signals, score, angle, email


# ─────────────────────────────────────────────────────────────────────
# BATCH MODE
# Reads a CSV file with columns: company_name, website, linkedin
# Processes all rows and adds a 1-second delay between companies.
#
# Example CSV format (companies.csv):
#   company_name,website,linkedin
#   HashiCorp,https://www.hashicorp.com,https://linkedin.com/company/hashicorp
#   Greenshades,https://www.greenshades.com,https://linkedin.com/company/greenshades-software
# ─────────────────────────────────────────────────────────────────────

def run_batch(csv_path):
    """Process multiple companies from a CSV file."""

    if not os.path.isfile(csv_path):
        print(f"❌ File not found: {csv_path}")
        sys.exit(1)

    with open(csv_path, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        rows = list(reader)

    print(f"\n📋 Batch mode — {len(rows)} companies to process")

    results = []
    for i, row in enumerate(rows, start=1):
        company  = row.get("company_name", "").strip()
        website  = row.get("website", "").strip()
        linkedin = row.get("linkedin", "").strip()

        if not company or not website:
            print(f"  ⚠️  Skipping row {i} — missing company_name or website")
            continue

        print(f"\n[{i}/{len(rows)}]", end=" ")

        signals, score, angle, email = run_pipeline(company, website, linkedin)
        results.append({
            "company":  company,
            "score":    score,
            "angle":    angle,
            "cloud":    signals["cloud_provider"],
        })

        if i < len(rows):
            time.sleep(1)  # polite delay between companies

    # Print batch summary sorted by score
    print(f"\n\n{'═'*60}")
    print(f"  BATCH COMPLETE — {len(results)} companies processed")
    print(f"{'═'*60}")
    print(f"\n  {'Company':<30} {'Score':>6}  {'Cloud':<20}  Value Angle")
    print(f"  {'─'*80}")
    for r in sorted(results, key=lambda x: x["score"], reverse=True):
        print(f"  {r['company']:<30} {r['score']:>5}/100  {r['cloud']:<20}  {r['angle']}")

    print(f"\n  Results saved to: {OUTPUT_FOLDER}/abm_master_results.csv")


# ─────────────────────────────────────────────────────────────────────
# ENTRY POINT
# ─────────────────────────────────────────────────────────────────────

if __name__ == "__main__":

    parser = argparse.ArgumentParser(
        description="ABM Engine — scrape, score, and generate outreach emails"
    )

    # Single company mode
    parser.add_argument("--company",  help="Company name")
    parser.add_argument("--website",  help="Company website URL")
    parser.add_argument("--linkedin", help="LinkedIn company page URL", default="")

    # Batch mode
    parser.add_argument(
        "--batch",
        help="Path to CSV file with columns: company_name, website, linkedin",
    )

    args = parser.parse_args()

    if args.batch:
        run_batch(args.batch)

    elif args.company and args.website:
        run_pipeline(args.company, args.website, args.linkedin)

    else:
        print(__doc__)
        print("\nExamples:")
        print("  python abm_engine_complete.py \\")
        print("    --company HashiCorp \\")
        print("    --website https://www.hashicorp.com \\")
        print("    --linkedin https://linkedin.com/company/hashicorp")
        print()
        print("  python abm_engine_complete.py --batch companies.csv")
        print()
        print("CSV format for --batch:")
        print("  company_name,website,linkedin")
        print("  HashiCorp,https://www.hashicorp.com,https://linkedin.com/company/hashicorp")
        print("  Greenshades,https://www.greenshades.com,https://linkedin.com/company/greenshades-software")
        sys.exit(1)