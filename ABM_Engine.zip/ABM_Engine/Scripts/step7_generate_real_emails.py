import csv
from openai import OpenAI

# Replace with your real key
client = OpenAI(api_key="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")

INPUT_FILE = "../abm_ai_outreach_messages.csv"
OUTPUT_FILE = "../abm_final_emails.csv"

with open(INPUT_FILE, "r", encoding="utf-8") as infile, \
     open(OUTPUT_FILE, "w", newline="", encoding="utf-8") as outfile:

    reader = csv.DictReader(infile)
    writer = csv.DictWriter(outfile, fieldnames=["company_name", "generated_email"])
    writer.writeheader()

    for row in reader:
        company = row["company_name"]
        prompt = row["ai_prompt"]

        print("Generating email for:", company)

        try:
            response = client.chat.completions.create(
                model="gpt-3.5-turbo",
                messages=[
                    {"role": "system", "content": "You are an expert sales assistant."},
                    {"role": "user", "content": prompt}
                ]
            )

            email = response.choices[0].message.content

        except Exception as e:
            print("API ERROR for company:", company)
            print(e)
            email = f"Error: {str(e)}"

        writer.writerow({
            "company_name": company,
            "generated_email": email
        })

print("✅ Real emails generated successfully!")