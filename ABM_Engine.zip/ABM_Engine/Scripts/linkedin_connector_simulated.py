# Simulated LinkedIn job ingestion using a public job API
# This replaces illegal LinkedIn scraping

import requests

def fetch_job_descriptions(company_name):

    print(f"Fetching job data for: {company_name}")

    url = "https://remotive.com/api/remote-jobs"

    try:
        response = requests.get(url)
        data = response.json()

        jobs = data.get("jobs", [])

        job_text = ""

        for job in jobs:
            if company_name.lower() in job["company_name"].lower():
                job_text += f"\nJob Title: {job['title']}\n"
                job_text += f"Description: {job['description']}\n"

        if job_text == "":
            job_text = "No jobs found from API source."

        return job_text

    except Exception as e:
        print("API error:", e)
        return "API fetch failed"
