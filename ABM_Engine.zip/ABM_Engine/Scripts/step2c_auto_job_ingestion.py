import os
from linkedin_connector_simulated import fetch_job_descriptions

RAW_FOLDER = "../raw_data"
COMPANIES_FILE = "../input/companies.txt"

with open(COMPANIES_FILE, "r") as f:
    companies = [line.strip() for line in f.readlines()]

for company in companies:

    print(f"\nProcessing company: {company}")

    job_data = fetch_job_descriptions(company)

    # NEW FALLBACK LOGIC ADDED HERE
    if "No jobs found" in job_data:
        sample_file = f"../input/sample_jobs/{company.lower().replace(' ', '_')}_sample_job.txt"

        if os.path.exists(sample_file):
            print("Using fallback sample job data...")
            with open(sample_file, "r", encoding="utf-8") as f:
                job_data = f.read()
        else:
            print("No sample job data available – keeping API response.")

    raw_file = os.path.join(RAW_FOLDER, f"{company.lower().replace(' ', '_')}_raw.txt")

    with open(raw_file, "a", encoding="utf-8") as f:
        f.write("\n\n--- AUTOMATED JOB DATA (SIMULATED LINKEDIN SOURCE) ---\n")
        f.write(job_data)

    print(f"Job data appended for {company}")

