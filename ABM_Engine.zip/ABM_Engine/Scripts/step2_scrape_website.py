import requests
from bs4 import BeautifulSoup

# Browser-like headers to reduce blocking
HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"
}

# Read input file
with open("../input/company_websites.txt", "r", encoding="utf-8") as file:
    lines = file.readlines()

for line in lines:
    if "," not in line:
        continue

    company, url = line.strip().split(",", 1)
    company_clean = company.lower().replace(" ", "_")
    output_file = f"../raw_data/{company_clean}_raw.txt"

    print(f"\nScraping website for: {company}")

    try:
        response = requests.get(url, headers=HEADERS, timeout=15)

        with open(output_file, "a", encoding="utf-8") as f:
            f.write("\n\n--- WEBSITE SCRAPE ATTEMPT ---\n")
            f.write(f"URL: {url}\n")
            f.write(f"HTTP Status Code: {response.status_code}\n")

            # If blocked or forbidden
            if response.status_code != 200:
                f.write("Website scraping blocked or restricted.\n")
                print("⚠️ Website blocked or restricted.")
                continue

            soup = BeautifulSoup(response.text, "html.parser")
            text = soup.get_text(separator="\n")

            # Detect bot protection text
            if "verifying your browser" in text.lower() or "security check" in text.lower():
                f.write("Bot protection detected. Website content not accessible.\n")
                print("⚠️ Bot protection detected.")
            else:
                f.write("\n--- WEBSITE CONTENT ---\n")
                f.write(text[:15000])  # limit size
                print("✅ Website content saved.")

    except Exception as e:
        with open(output_file, "a", encoding="utf-8") as f:
            f.write("\n--- WEBSITE SCRAPE ERROR ---\n")
            f.write(str(e))
        print("❌ Error while scraping website.")
