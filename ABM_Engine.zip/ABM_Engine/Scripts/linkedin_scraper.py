from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager
import time


def scrape_linkedin_company(linkedin_url, email, password):
    options = Options()
    options.add_argument("--start-maximized")

    driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=options)

    try:
        # Open LinkedIn login
        driver.get("https://www.linkedin.com/login")
        time.sleep(2)

        # Login
        driver.find_element(By.ID, "username").send_keys(email)
        driver.find_element(By.ID, "password").send_keys(password)
        driver.find_element(By.XPATH, "//button[@type='submit']").click()

        time.sleep(5)

        # Go to company page
        driver.get(linkedin_url)
        time.sleep(5)

        page_text = driver.find_element(By.TAG_NAME, "body").text

        return page_text

    except Exception as e:
        return f"LinkedIn scraping error: {e}"

    finally:
        driver.quit()
