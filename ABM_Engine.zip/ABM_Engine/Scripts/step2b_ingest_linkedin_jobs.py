# STEP L3: Ingest LinkedIn job descriptions into raw data files

import os

LINKEDIN_FOLDER = "../input/linkedin_jobs"
RAW_DATA_FOLDER = "../raw_data"

for filename in os.listdir(LINKEDIN_FOLDER):
    if not filename.endswith("_jobs.txt"):
        continue

    company_name = filename.replace("_jobs.txt", "")
    raw_file_path = os.path.join(RAW_DATA_FOLDER, f"{company_name}_raw.txt")
    linkedin_file_path = os.path.join(LINKEDIN_FOLDER, filename)

    # Check if raw file exists
    if not os.path.exists(raw_file_path):
        print(f"⚠️ Raw file not found for {company_name}, skipping.")
        continue

    with open(linkedin_file_path, "r", encoding="utf-8") as job_file:
        job_text = job_file.read()

    with open(raw_file_path, "a", encoding="utf-8") as raw_file:
        raw_file.write("\n\n--- LINKEDIN JOB DESCRIPTION ---\n")
        raw_file.write(job_text)

    print(f"✅ LinkedIn job data added for {company_name}")
