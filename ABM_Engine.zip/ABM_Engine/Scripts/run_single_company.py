import sys
import os
import requests
from bs4 import BeautifulSoup
from datetime import datetime

from step3_extract_signals import extract_signals


BASE_DIR = os.path.dirname(os.path.dirname(__file__))
OUTPUT_FOLDER = os.path.join(BASE_DIR, "single_company_outputs")

if not os.path.exists(OUTPUT_FOLDER):
    os.makedirs(OUTPUT_FOLDER)


EXTRA_PATHS = [
    "",
    "/careers",
    "/jobs",
    "/about",
    "/security",
    "/technology",
    "/integrations"
]


def scrape_page(url):

    try:

        headers = {
            "User-Agent": "Mozilla/5.0"
        }

        response = requests.get(url, headers=headers, timeout=15)

        if response.status_code != 200:
            return ""

        soup = BeautifulSoup(response.text, "html.parser")

        # Capture infra signals BEFORE removing scripts
        infra_sources = []

        for script in soup.find_all("script", src=True):
            infra_sources.append(script["src"])

        for link in soup.find_all("link", href=True):
            infra_sources.append(link["href"])

        for meta in soup.find_all("meta"):
            if meta.get("content"):
                infra_sources.append(meta.get("content"))

        infra_text = " ".join(infra_sources)

        # Remove visible junk
        for tag in soup(["script", "style", "noscript"]):
            tag.decompose()

        visible_text = soup.get_text(separator=" ", strip=True)

        return visible_text + " " + infra_text

    except:
        return ""


def scrape_full_website(base_url):

    full_text = ""

    for path in EXTRA_PATHS:

        url = base_url.rstrip("/") + path

        print(f"Scraping: {url}")

        page_text = scrape_page(url)

        if len(page_text) > 200:
            full_text += f"\n\n--- {url} ---\n\n"
            full_text += page_text

    return full_text


if len(sys.argv) != 3:

    print("Usage:")
    print("python run_single_company.py <website> <linkedin>")
    sys.exit(1)


website_url = sys.argv[1]
linkedin_url = sys.argv[2]

company_name = website_url.replace("https://", "").replace("http://", "").replace("www.", "").split(".")[0]


print("\nRunning full scraper...")

website_text = scrape_full_website(website_url)

linkedin_text = scrape_page(linkedin_url)

full_text = website_text + "\n\n" + linkedin_text


signals = extract_signals(full_text)


print("\nFINAL SIGNALS:\n")

for k, v in signals.items():
    print(k, ":", v)


timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

output_file = os.path.join(
    OUTPUT_FOLDER,
    f"{company_name}_{timestamp}.txt"
)


with open(output_file, "w", encoding="utf-8") as f:

    f.write("=== SIGNALS ===\n")

    for k, v in signals.items():
        f.write(f"{k}: {v}\n")

    f.write("\n\n=== FULL SCRAPE ===\n\n")
    f.write(full_text)


print("\nSaved to:", output_file)