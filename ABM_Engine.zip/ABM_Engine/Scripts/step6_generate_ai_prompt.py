import os
import csv

# -------- PATHS --------
BASE_DIR = os.path.dirname(os.path.dirname(__file__))

INPUT_FILE = os.path.join(BASE_DIR, "abm_scored_accounts.csv")
OUTPUT_FILE = os.path.join(BASE_DIR, "abm_ai_outreach_messages.csv")


def build_prompt(row):

    company = row["company_name"]
    cloud = row["cloud_provider"]
    kubernetes = row["kubernetes"]
    devops = row["devops_hiring"]
    sre = row["sre_hiring"]
    multi = row["multi_cloud"]
    security = row["security_focus"]
    micro = row["microservices"]
    ai = row["ai_ml"]
    data = row["data_platform"]
    finops = row["finops"]
    observability = row["observability"]
    compliance = row["compliance_domain"]
    score = row["priority_score"]
    angle = row["value_angle"]

    prompt = f"""
You are a B2B sales outreach AI.

Create a short, professional, personalized outreach email for this company.

COMPANY PROFILE
---------------
Company Name: {company}
Cloud Provider: {cloud}
Using Kubernetes: {kubernetes}
DevOps Hiring: {devops}
SRE Hiring: {sre}
Multi-Cloud: {multi}
Security Focus: {security}
Microservices Architecture: {micro}
AI/ML Usage: {ai}
Data Platform Usage: {data}
FinOps Practice: {finops}
Observability Practice: {observability}
Compliance Domain: {compliance}

ABM CONTEXT
-----------
Priority Score: {score}
Recommended Value Angle: {angle}

INSTRUCTIONS
------------
- Write a friendly, concise email (max 120 words)
- Address Head of Engineering or CTO
- Use the value angle as the main theme
- Mention only relevant detected signals
- Do NOT invent facts
- Include a clear call to action for a short intro call

OUTPUT FORMAT
-------------
Subject:
Email Body:

Generate ONLY the email content.
"""

    return prompt


print("📨 Generating AI outreach prompts...")

with open(INPUT_FILE, "r", encoding="utf-8") as infile, \
     open(OUTPUT_FILE, "w", newline="", encoding="utf-8") as outfile:

    reader = csv.DictReader(infile)

    fieldnames = ["company_name", "ai_prompt"]

    writer = csv.DictWriter(outfile, fieldnames=fieldnames)
    writer.writeheader()

    for row in reader:

        prompt = build_prompt(row)

        writer.writerow({
            "company_name": row["company_name"],
            "ai_prompt": prompt
        })

print("✅ AI prompts generated and saved to abm_ai_outreach_messages.csv")
