import os
import csv

# -------- PATHS --------
BASE_DIR = os.path.dirname(os.path.dirname(__file__))

INPUT_DB = os.path.join(BASE_DIR, "abm_signals.csv")
OUTPUT_DB = os.path.join(BASE_DIR, "abm_scored_accounts.csv")


def score_company(row):

    score = 0
    angle = "General Outreach"

    # Cloud provider score
    if row["cloud_provider"] in ["AWS", "Azure", "GCP"]:
        score += 20
    elif row["cloud_provider"] == "Cloud-Based":
        score += 15

    # Kubernetes importance
    if row["kubernetes"] == "Yes":
        score += 20

    # DevOps hiring signal
    if row["devops_hiring"] == "Yes":
        score += 15

    # SRE hiring signal
    if row["sre_hiring"] == "Yes":
        score += 10

    # Multi-cloud signal
    if row["multi_cloud"] == "Yes":
        score += 10

    # Security focus
    if row["security_focus"] == "Yes":
        score += 10

    # Microservices architecture
    if row["microservices"] == "Yes":
        score += 10

    # AI / ML usage
    if row["ai_ml"] == "Yes":
        score += 10

    # Data platform usage
    if row["data_platform"] == "Yes":
        score += 10

    # FinOps usage
    if row["finops"] == "Yes":
        score += 10

    # Observability usage
    if row["observability"] == "Yes":
        score += 10

    # Compliance domain importance
    if row["compliance_domain"] in ["Financial", "Healthcare", "Payroll / Tax"]:
        score += 15

    # -------- DETERMINE VALUE ANGLE --------

    if row["kubernetes"] == "Yes":
        angle = "Kubernetes Optimization"

    elif row["devops_hiring"] == "Yes" or row["sre_hiring"] == "Yes":
        angle = "Cloud Reliability & DevOps Automation"

    elif row["security_focus"] == "Yes":
        angle = "Cloud Security & Governance"

    elif row["ai_ml"] == "Yes":
        angle = "AI/ML Infrastructure Scaling"

    elif row["data_platform"] == "Yes":
        angle = "Data Platform Modernization"

    elif row["multi_cloud"] == "Yes":
        angle = "Multi-Cloud Strategy"

    else:
        angle = "Platform Optimization"

    return score, angle


# -------- MAIN SCRIPT --------

print("📊 Running scoring engine...")

with open(INPUT_DB, "r", encoding="utf-8") as infile, \
     open(OUTPUT_DB, "w", newline="", encoding="utf-8") as outfile:

    reader = csv.DictReader(infile)

    fieldnames = list(reader.fieldnames) + ["priority_score", "value_angle"]

    writer = csv.DictWriter(outfile, fieldnames=fieldnames)
    writer.writeheader()

    for row in reader:

        score, angle = score_company(row)

        row["priority_score"] = score
        row["value_angle"] = angle

        writer.writerow(row)


print("✅ Scoring completed and saved to abm_scored_accounts.csv")
