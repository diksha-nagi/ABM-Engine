import os
import csv

# -------- PATH HANDLING --------
BASE_DIR = os.path.dirname(os.path.dirname(__file__))

RAW_DATA_FOLDER = os.path.join(BASE_DIR, "raw_data")
OUTPUT_DB = os.path.join(BASE_DIR, "abm_signals.csv")


def extract_signals(text):
    text_lower = text.lower()

    signals = {
        "cloud_provider": "Unknown",
        "kubernetes": "No",
        "devops_hiring": "No",
        "sre_hiring": "No",
        "multi_cloud": "No",
        "security_focus": "No",
        "microservices": "No",
        "ai_ml": "No",
        "data_platform": "No",
        "finops": "No",
        "observability": "No",
        "compliance_domain": "Low-Regulated"
    }

    # ---- CLOUD PROVIDER DETECTION ----
    if "aws" in text_lower or "eks" in text_lower:
        signals["cloud_provider"] = "AWS"
    elif "azure" in text_lower or "aks" in text_lower:
        signals["cloud_provider"] = "Azure"
    elif "gcp" in text_lower or "gke" in text_lower:
        signals["cloud_provider"] = "GCP"
    elif "cloud" in text_lower or "infrastructure" in text_lower:
        signals["cloud_provider"] = "Cloud-Based"

    # ---- TECHNOLOGY SIGNALS ----
    if "kubernetes" in text_lower or "eks" in text_lower or "aks" in text_lower:
        signals["kubernetes"] = "Yes"

    if "devops engineer" in text_lower or "devops hiring" in text_lower:
        signals["devops_hiring"] = "Yes"

    if "site reliability" in text_lower or "sre" in text_lower:
        signals["sre_hiring"] = "Yes"

    if "multi cloud" in text_lower or "multi-cloud" in text_lower:
        signals["multi_cloud"] = "Yes"

    if "security" in text_lower or "soc2" in text_lower or "iso27001" in text_lower:
        signals["security_focus"] = "Yes"

    if "microservice" in text_lower or "microservices" in text_lower:
        signals["microservices"] = "Yes"

    if "ai" in text_lower or "machine learning" in text_lower:
        signals["ai_ml"] = "Yes"

    if "data platform" in text_lower or "analytics" in text_lower:
        signals["data_platform"] = "Yes"

    if "finops" in text_lower or "cloud cost" in text_lower:
        signals["finops"] = "Yes"

    if "monitoring" in text_lower or "observability" in text_lower:
        signals["observability"] = "Yes"

    # ---- COMPLIANCE ----
    if "payroll" in text_lower or "tax" in text_lower:
        signals["compliance_domain"] = "Payroll / Tax"
    elif "healthcare" in text_lower or "hipaa" in text_lower:
        signals["compliance_domain"] = "Healthcare"
    elif "finance" in text_lower:
        signals["compliance_domain"] = "Financial"

    return signals


# -------- WRITE TO CSV DATABASE --------

file_exists = os.path.isfile(OUTPUT_DB)

with open(OUTPUT_DB, "a", newline="", encoding="utf-8") as csvfile:

    fieldnames = [
        "company_name",
        "cloud_provider",
        "kubernetes",
        "devops_hiring",
        "sre_hiring",
        "multi_cloud",
        "security_focus",
        "microservices",
        "ai_ml",
        "data_platform",
        "finops",
        "observability",
        "compliance_domain"
    ]

    writer = csv.DictWriter(csvfile, fieldnames=fieldnames)

    if not file_exists:
        writer.writeheader()

    for filename in os.listdir(RAW_DATA_FOLDER):

        if not filename.endswith("_raw.txt"):
            continue

        company_name = filename.replace("_raw.txt", "")
        file_path = os.path.join(RAW_DATA_FOLDER, filename)

        with open(file_path, "r", encoding="utf-8") as f:
            text = f.read()

        signals = extract_signals(text)

        row = {
            "company_name": company_name,
            "cloud_provider": signals["cloud_provider"],
            "kubernetes": signals["kubernetes"],
            "devops_hiring": signals["devops_hiring"],
            "sre_hiring": signals["sre_hiring"],
            "multi_cloud": signals["multi_cloud"],
            "security_focus": signals["security_focus"],
            "microservices": signals["microservices"],
            "ai_ml": signals["ai_ml"],
            "data_platform": signals["data_platform"],
            "finops": signals["finops"],
            "observability": signals["observability"],
            "compliance_domain": signals["compliance_domain"]
        }

        writer.writerow(row)

print("✅ Signals saved to database (CSV).")
