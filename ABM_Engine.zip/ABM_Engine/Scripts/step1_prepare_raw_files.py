# Step 1: Read company names and create raw data files

with open("../input/companies.txt", "r") as file:
    companies = file.readlines()

for company in companies:
    company = company.strip().lower().replace(" ", "_")
    filename = f"../raw_data/{company}_raw.txt"

    with open(filename, "w") as raw_file:
        raw_file.write(f"Raw data file for {company}\n")

print("Raw data files created successfully.")
